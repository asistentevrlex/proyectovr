WL.registerComponent('button', {
    buttonMeshObject: {type: WL.Type.Object},
    hoverMaterial: {type: WL.Type.Material},
}, {
    start: function() {
        this.mesh = this.buttonMeshObject.getComponent('mesh');
        this.defaultMaterial = this.mesh.material;

        this.target = this.object.getComponent('cursor-target');
        this.target.addHoverFunction(this.onHover.bind(this));
        this.target.addUnHoverFunction(this.onUnHover.bind(this));
        this.target.addDownFunction(this.onDown.bind(this));
        this.target.addUpFunction(this.onUp.bind(this));

        this.soundClick = this.object.addComponent('howler-audio-source', {src: 'sfx/click.wav', spatial: true});
        this.soundUnClick = this.object.addComponent('howler-audio-source', {src: 'sfx/unclick.wav', spatial: true});

        //Cargamos scripts aws
        console.log('iniciando scripts Amazon LEX');
        //script sdk aws
        var script = document.createElement('script');
        script.src = "https://sdk.amazonaws.com/js/aws-sdk-2.1343.0.min.js"; document.head.appendChild(script);
        //script lex-audio
        var script = document.createElement('script');
        script.src = "dist/aws-lex-audio.js";
        script.type = "text/javascript";
        document.head.appendChild(script);
        //script reder
        var script = document.createElement('script');
        script.src = "renderer.js";
        script.type = "text/javascript";
        document.head.appendChild(script);

        //agregamos elementos html que requiere Amazon LEX //CSV para ocultar los elementos html
        var style = document.createElement('style');
        style.type = 'text/css';
        style.innerHTML = '.audio-control { display: none;}'; document.getElementsByTagName('head')[0].appendChild(style);
        //Cargamos elementos html // Create a new div element
        var div = document.createElement('div');
        // Set the content of the div element
        //div.className = "hidden";
        div.className = "audio-control"
        div.innerHTML = '<p id="audio-control" class="white-circle"> <img src="lex.png"><canvas class="visualizer"></canvas></p><p><span id="message"></span></p>';
        // Add the div element to the body of the HTML page document.body.appendChild(div);
        document.body.appendChild(div);
    },

    onHover: function(_, cursor) {
        this.mesh.material = this.hoverMaterial;
        if(cursor.type == 'finger-cursor') {
            this.onDown(_, cursor);
        }

        this.hapticFeedback(cursor.object, 0.5, 50);
    },

    onDown: function(_, cursor) {
        this.soundClick.play();
        this.buttonMeshObject.translate([0.0, -0.1, 0.0]);
        this.hapticFeedback(cursor.object, 1.0, 20);
    },

    onUp: function(_, cursor) {
        this.soundUnClick.play();
        this.buttonMeshObject.translate([0.0, 0.1, 0.0]);
        this.hapticFeedback(cursor.object, 0.7, 20);

        // Funciones AWS
        var waveform = window.Waveform();
        var message = document.getElementById('message'); var config, conversation;
        message.textContent = 'Passive';
        AWS.config.credentials = new AWS.Credentials("AKIAXAOA3E3CATIDQBU2", "Rr7RY15T6cGqvE3oLJt1fe/yBRnEanbrECQJhZNk", null);
        AWS.config.region = 'us-east-1'; //console.log(AWS.config.credentials);
        config = {
        lexConfig: { botName: "Reservaunhotel" }
        };
        conversation = new LexAudio.conversation(config, function (state) { message.textContent = state + '...';
        if (state === 'Listening') {
        waveform.prepCanvas(); }
        if (state === 'Sending') { waveform.clearCanvas();
        }
        }, function (data) {
        console.log('Transcript: ', data.inputTranscript, ", Response: ", data.message); }, function (error) {
        message.textContent = error;
        }, function (timeDomain, bufferLength) {
        waveform.visualizeAudioBuffer(timeDomain, bufferLength); });
        conversation.advanceConversation();

    },

    onUnHover: function(_, cursor) {
        this.mesh.material = this.defaultMaterial;
        if(cursor.type == 'finger-cursor') {
            this.onUp(_, cursor);
        }

        this.hapticFeedback(cursor.object, 0.3, 50);
    },

    hapticFeedback: function(object, strength, duration) {
        const input = object.getComponent('input');
        if(input && input.xrInputSource) {
            const gamepad = input.xrInputSource.gamepad;
            if(gamepad && gamepad.hapticActuators) gamepad.hapticActuators[0].pulse(strength, duration);
        }
    },
});
